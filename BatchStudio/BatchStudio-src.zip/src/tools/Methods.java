package tools;

import gfx.Editor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class Methods {
	
	public static final String RESFOLDER = "res/";
	public static final String BSFOLDER = RESFOLDER+"bs/";
	public static final String IMGFOLDER = RESFOLDER+"img/";
	private static File lastfile;
	private static File sample = new File(BSFOLDER+"sample.bsbat");
	
	public static void newFile(File file) throws IOException {
		FileInputStream samp = new FileInputStream(sample);
		ReadableByteChannel rbc = Channels.newChannel(samp);
		FileOutputStream fos = new FileOutputStream(file);
		
		fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
		fos.close();
		samp.close();
		rbc.close();
		setLastfile(file);
	}

	public static void newEditor(File selectedFile) {
		new Editor(selectedFile);
		setLastfile(selectedFile);
		
	}

	public static File getLastfile() {
		return lastfile;
	}

	public static void setLastfile(File lastfile) {
		Methods.lastfile = lastfile;
	}
}
