package gfx;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import tools.Methods;


public class Editor extends JFrame {
	
	protected JTextPane textPane;
	protected File file;
	private JPanel contentPane;
	
	
//---------------------------------------------------------------------------------------------------
	
	
	public File getFile() {
		return file;
	}
	public Editor(File file) {
	
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				saveOld();
				setVisible(false);
			}
		});
		setTitle("BatchStudio 1.0");
		try {
			
			 UIManager.setLookAndFeel(
			     UIManager.getSystemLookAndFeelClassName()
			     );
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e2) {
			e2.printStackTrace();
		}
		this.file = file;
		
		setResizable(false);
		setVisible(true);
		setTitle(file.getAbsolutePath());
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 733, 475);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(10, 93, 707, 341);
		contentPane.add(scrollPane);
		
	    textPane = new JTextPane();
	    scrollPane.setViewportView(textPane);
	    textPane.setFont(new Font("AR CENA", Font.PLAIN, 20));
		try {
			textPane.read(new FileReader(file),null);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				save();
			}
		});
		btnNewButton.setFocusPainted(false);
		btnNewButton.setIcon(new ImageIcon(Methods.IMGFOLDER + "save.png"));
		btnNewButton.setBounds(10, 30, 48,48);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 openFile();
			}
		});
		button.setFocusPainted(false);
		button.setIcon(new ImageIcon(Methods.IMGFOLDER + "open.png"));
		button.setBounds(100, 30, 48, 48);
		contentPane.add(button);
		
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				run();
			}
		});
		button_1.setBounds(190, 30, 48, 48);
		button_1.setIcon(new ImageIcon(Methods.IMGFOLDER + "run.png"));
		button_1.setFocusPainted(false);
		contentPane.add(button_1);
		
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 727, 21);
		contentPane.add(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmSave = new JMenuItem("Save");
		mntmSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				save();
			}
		});
		mnFile.add(mntmSave);
		
		JMenuItem mntmSaveAs = new JMenuItem("Save as");
		mntmSaveAs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				saveOld();
				ReadableByteChannel rbc = Channels.newChannel(new FileInputStream(getFile()));
				JFileChooser jfc = new JFileChooser(System.getProperty("user.home")+"/Desktop");
				
				  FileNameExtensionFilter filter = new FileNameExtensionFilter(
					      "Batch Files (BAT, CMD)", "bat", "cmd");
				    jfc.setFileFilter(filter);
				int op = jfc.showSaveDialog(null);
				if(op==JFileChooser.APPROVE_OPTION){
					  File theFile = jfc.getSelectedFile();
					  if(!(theFile.getAbsolutePath().endsWith(".bat") || theFile.getAbsolutePath().endsWith(".cmd"))){theFile = new File(theFile.getAbsolutePath()+".cmd");}
					int conf = JOptionPane.showConfirmDialog(null, "The file " + theFile.getAbsolutePath() +" will be opened.","Confirm", JOptionPane.OK_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE);
					
					  if(conf == 0){
						  
						  FileOutputStream fos = new FileOutputStream(theFile);
						  fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
						  fos.close();
						  Methods.newEditor(theFile);
					  }
				}
				else{};
				
				}catch(Exception exx){exx.printStackTrace();System.exit(1);}	    
			}

			
		});
		
		mnFile.add(mntmSaveAs);
		
		JMenuItem mntmOpen = new JMenuItem("Open");
		mntmOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openFile();
			}
		});
		mnFile.add(mntmOpen);
		
		try {
			FileInputStream fr = new FileInputStream(file);
			textPane.read(fr, null);
			fr.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		save();
		setIconImage(Toolkit.getDefaultToolkit().getImage(Methods.IMGFOLDER + "icon.png"));
	}
	protected void run() {
	
		ProcessBuilder pb = new ProcessBuilder("cmd","/k","start \"",file.getAbsolutePath(),"\"");
		pb.directory(file.getParentFile());
		try {
			Process p = pb.start();
		
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	protected void openFile() {
		saveOld();
		 JFileChooser chooser = new JFileChooser(System.getProperty("user.home")+"/Desktop");
		  FileNameExtensionFilter filter = new FileNameExtensionFilter(
			        "Batch Files (BAT, CMD)", "bat", "cmd");
		    chooser.setFileFilter(filter);
		    
		  int x = chooser.showSaveDialog(this);
		  if(x==JFileChooser.APPROVE_OPTION){
			  File theFile = chooser.getSelectedFile();
			  if(!(theFile.getAbsolutePath().endsWith(".bat") || theFile.getAbsolutePath().endsWith(".cmd"))){theFile = new File(theFile.getAbsolutePath()+".cmd");}
			int conf = JOptionPane.showConfirmDialog(null, "The file " + theFile.getAbsolutePath() +" will be opened.","Confirm", JOptionPane.OK_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE);
			  if(conf == 0){Methods.newEditor(theFile);}
			  else return;
		  }
		  else{
			 return; 
		  }
	}
		
	private void save() {
		try {
			
			textPane.write(new FileWriter(file));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	@Override
	public void setTitle(String title){
		super.setTitle(title + " - BatchStudio");
		
	}
	protected void saveOld(){
		int a;
		a = JOptionPane.showConfirmDialog(null, "Do you want to save file " + getFile().getAbsolutePath() + "?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if(a == 0){
			save();
		}
		else{};
		
	}
	
}
