package gfx;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import tools.Methods;


public class Window extends JFrame {

	private JPanel contentPane;
	public Window(){

		setTitle("BatchStudio 1.0");
		try {
			
			 UIManager.setLookAndFeel(
			     UIManager.getSystemLookAndFeelClassName()
			     );
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e2) {
			
			e2.printStackTrace();
		}
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(626, 393);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel wlc = new JLabel("Welcome to BatchStudio 1.0");
		wlc.setFont(new Font("AR CENA", Font.BOLD, 40));
		wlc.setBounds(93, 35, 507, 43);
		contentPane.add(wlc);
		
		JButton btnNewButton = new JButton("New Project");
		btnNewButton.setVisible(true);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  JFileChooser chooser = new JFileChooser(System.getProperty("user.home")+"/Desktop");
				  FileNameExtensionFilter filter = new FileNameExtensionFilter(
					        "Batch Files (BAT, CMD)", "bat", "cmd");
				    chooser.setFileFilter(filter);
				    
				  int x = chooser.showSaveDialog(null);
				  if(x==JFileChooser.APPROVE_OPTION){
					  File theFile = chooser.getSelectedFile();
					  if(!(theFile.getAbsolutePath().endsWith(".bat") || theFile.getAbsolutePath().endsWith(".cmd"))){theFile = new File(theFile.getAbsolutePath()+".cmd");}
					int conf = JOptionPane.showConfirmDialog(null, "The file " + theFile.getAbsolutePath() +" will be opened.","Confirm", JOptionPane.OK_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE);
					  if(conf == 0){try {
						Methods.newFile(theFile);
						Methods.newEditor(theFile);
					} catch (IOException e1) {
						e1.printStackTrace();
					}}
					  else return;
				  }
				  else{
					 return; 
				  }
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 25));
		btnNewButton.setBounds(37, 101, 222, 92);
		contentPane.add(btnNewButton);
		
		JButton btnOpenFile = new JButton("Open file");
		btnOpenFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JFileChooser chooser = new JFileChooser(System.getProperty("user.home")+"/Desktop");
				  FileNameExtensionFilter filter = new FileNameExtensionFilter(
					        "Batch Files (BAT, CMD)", "bat", "cmd");
				    chooser.setFileFilter(filter);
					  int x = chooser.showOpenDialog(null);
					  if(x==JFileChooser.APPROVE_OPTION){
						  File theFile = chooser.getSelectedFile();
							
							if (!(theFile.exists())){
								JOptionPane.showMessageDialog(null, "File not found", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							else{
							
						int conf = JOptionPane.showConfirmDialog(null, "The file " + theFile.getAbsolutePath() +" will be opened.","Confirm", JOptionPane.OK_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE);
						  if(conf == 0){Methods.newEditor(theFile);}
						  else return;
							}
					  }
					  else{
						 return; 
					  }
				    
			}
		});
		btnOpenFile.setFont(new Font("Tahoma", Font.BOLD, 25));
		btnOpenFile.setBounds(352, 101, 222, 92);
		contentPane.add(btnOpenFile);
		
		JButton btnAbout = new JButton("About");
		btnAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{new AboutWindow();}catch(Exception ex){ex.printStackTrace();JOptionPane.showMessageDialog(null, "Couldn't find the about.bstxt file.","Error",0);}
			}
		});
		btnAbout.setFont(new Font("Tahoma", Font.BOLD, 25));
		btnAbout.setBounds(37, 226, 222, 92);
		contentPane.add(btnAbout);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 25));
		btnExit.setBounds(352, 226, 222, 92);
		contentPane.add(btnExit);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Methods.IMGFOLDER + "icon.png"));
	}
}
