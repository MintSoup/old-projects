package gfx;

import java.awt.Font;
import java.awt.Toolkit;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;

import tools.Methods;

public class AboutWindow extends JFrame {

	private JPanel contentPane;

	public AboutWindow() throws IOException {
		setVisible(true);
		setTitle("BatchStudio 1.0");
		try {
			
			 UIManager.setLookAndFeel(
			     UIManager.getSystemLookAndFeelClassName()
			     );
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e2) {
			e2.printStackTrace();
		}
		setTitle("About BatchStudio");
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(600,300);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 10, 574, 249);
		contentPane.add(scrollPane);
		FileReader r=null;
		try{
		r = new FileReader(Methods.BSFOLDER+"about.bstxt");
		}catch(FileNotFoundException e){e.printStackTrace();this.setVisible(false);}
		JTextArea textArea = new JTextArea();
		textArea.setBackground(UIManager.getColor("CheckBox.background"));
		textArea.setEditable(false);
	
		scrollPane.setViewportView(textArea);
		textArea.setFont(new Font("Calibri", Font.PLAIN, 20));
		textArea.read(r,null);
		
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(Methods.IMGFOLDER + "icon.png"));
	}
}
